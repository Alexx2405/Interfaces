/* NOMBRE APELLIDOS */

$(document).ready(function(){

    /* Ejercicio 1 */
    

    /* Ejercicio 2 */
    

    /* Ejercicio 3 */
    

    /* Ejercicio 4 */
    

    /* Ejercicio 5 */
    

    /* Ejercicio 6 */
    

    /* Ejercicio 7 */
    
    
});